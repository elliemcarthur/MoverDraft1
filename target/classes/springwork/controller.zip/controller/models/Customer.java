package springwork.controller.models;

public class Customer {
private long cid;
private long userid;
private String city;
private String state;

public Customer() {
	
}
public Customer(long cid, long userid, String city, String state) {
	super();
	this.cid = cid;
	this.userid = userid;
	this.city = city;
	this.state = state;
}
public long getCid() {
	return cid;
}
public void setCid(long cid) {
	this.cid = cid;
}
public long getUserid() {
	return userid;
}
public void setUserid(long userid) {
	this.userid = userid;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}

}
