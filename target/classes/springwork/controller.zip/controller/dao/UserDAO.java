package springwork.controller.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import springwork.controller.models.User;

public class UserDAO implements UserDAOI{
	JdbcTemplate template;  
	
	
	public void setTemplate(JdbcTemplate template) {  
	    this.template = template;  
	}  

     @Autowired
     DataSource datasource;
	
public int saveFirstPage(User user){  
    String sql="insert into reguser(uname,pass,passw2, email) values(?, ?, ?, ?)";  
  
    return template.update(sql, user.getUname(), user.getPass(), user.getPassw2(),user.getEmail());  

}
 
@Override
public int updatenames(User user) {
	String sql="update reguser set fname=?, lname=? where uname=?";
	return template.update(sql, user.getFname(), user.getLname(), user.getUname());
}
@Override
public void update(User user){  
	
    String sql="update reguser set email=?, pass=?, passw2=?, fname=?, lname=? where email=?";
    JdbcTemplate jdbcTemplate = new JdbcTemplate(datasource);  
    
    jdbcTemplate.update(  
      sql,  
      new Object[] { user.getEmail(), user.getPass(),  
        user.getPassw2(), user.getFname(), user.getLname() });  
 // return template.update(sql, user.getEmail(),user.getPass(), user.getPassw2(), user.getFname(), user.getLname(), user.getEmail());
   
}  
@Override
public int delete(String email){  
    String sql="delete from reguser where email=?";  
    return template.update(sql,email );  
}  
@Override
public User getUserById(String email){  
    List<User> userList = new ArrayList<User>(); 
    String sql="select * from reguser where email=" + email;  
    
     JdbcTemplate jdbcTemplate = new JdbcTemplate(datasource);  
     userList = jdbcTemplate.query(sql, new UserRowMapper());  
     return userList.get(0);  
    }  

@Override
public List<User> getUsers(){  
    return template.query("select * from reguser",new RowMapper<User>(){  
        public User mapRow(ResultSet rs, int row) throws SQLException {  
            User user=new User();  
            user.setUserid(rs.getLong("userid"));  
            user.setUname(rs.getString("uname"));  
            user.setPass(rs.getString("pass"));  
            user.setPassw2(rs.getString("passw2"));  
            user.setEmail(rs.getString("email"));  
            user.setFname(rs.getString("fname"));  
            user.setLname(rs.getString("lname")); 
            return user;  
        }  
    });  
}



}
