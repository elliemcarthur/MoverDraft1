package springwork.controller.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import springwork.controller.models.Customer;


public class CustomerDAO implements CustomerDAOI{
	JdbcTemplate template;  
	  
	public void setTemplate(JdbcTemplate template) {  
	    this.template = template;  
	}  
	@Override
	public int registerCustomer(Customer customer){  
	    String sql="insert into customers(userid,city,state) values(?, ?, ?)";  
	    return template.update(sql, customer.getUserid(), customer.getCity(), customer.getState());  
	}  

	@Override
	public int updateCustomer(Customer customer) {
		String sql="update customers set city=?,state=?";
		return template.update(sql, customer.getCity(), customer.getState());
	}
	
	@Override
	public long delete(long cid){  
	    String sql="delete from reguser where cid=?";  
	    return template.update(sql, cid);  
	}  
	@Override
	public Customer getCustomerById(long cid){  
	    String sql="select * from customers where cid=?";  
	    return template.queryForObject(sql, new Object[]{cid},new BeanPropertyRowMapper<Customer>(Customer.class));  
	}  
	@Override
	public List<Customer> getCustomers(){  
	    return template.query("select * from customers",new RowMapper<Customer>(){  
	        public Customer mapRow(ResultSet rs, int row) throws SQLException {  
	            Customer customer=new Customer();  
	            customer.setCid(rs.getLong("cid"));
	            customer.setUserid(rs.getLong("userid"));  
	            customer.setCity(rs.getString("city"));  
	            customer.setState(rs.getString("state"));  
	            return customer;  
	        }  
	    });  
	}  

}
