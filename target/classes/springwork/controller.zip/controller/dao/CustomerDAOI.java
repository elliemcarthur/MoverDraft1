package springwork.controller.dao;

import java.util.List;

import springwork.controller.models.Customer;

public interface CustomerDAOI {


	int registerCustomer(Customer customer);

	int updateCustomer(Customer customer);

	long delete(long cid);

	Customer getCustomerById(long cid);

	List<Customer> getCustomers();
}
