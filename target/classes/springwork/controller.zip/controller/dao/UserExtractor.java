package springwork.controller.dao;



import java.sql.ResultSet;  
import java.sql.SQLException;  
import org.springframework.dao.DataAccessException;  
import org.springframework.jdbc.core.ResultSetExtractor;

import springwork.controller.models.User;  

  
public class UserExtractor implements ResultSetExtractor<springwork.controller.models.User> {  
  
 public User extractData(ResultSet resultSet) throws SQLException,  
   DataAccessException {  
    
  User user = new User();  
    
  user.setUname(resultSet.getString(1));  
  user.setPass(resultSet.getString(2));  
  user.setPassw2(resultSet.getString(3));  
  user.setEmail(resultSet.getString(4));  
  user.setFname(resultSet.getString(5));  
  user.setLname(resultSet.getString(6));
    
  return user;  
 }  
  
}  