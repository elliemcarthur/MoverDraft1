package springwork.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import springwork.controller.dao.UserDAO;
import springwork.controller.models.User;

@Controller
@ControllerAdvice
@SessionAttributes("user")
public class DashboardController {
	@Autowired
	private UserDAO userdao;
	@ModelAttribute("user")
	public User setUpUserForm() {
		return new User();
	}

	//@ModelAttribute("user")
	@RequestMapping(value="/userdashboard")
	public ModelAndView loadHomeDash(@ModelAttribute("user") User user) {
		return new ModelAndView("userdashboard");
	} 
	@RequestMapping("/edituser/${user.uname)")
	public ModelAndView editUser(@ModelAttribute("user") User user, @PathVariable("user.uname") String uname) {
	 userdao.getUserById(uname);
		ModelAndView mav=new ModelAndView("edit");
		mav.addObject("user",user);
	return mav;
	}
	@RequestMapping(value="/editsave", method=RequestMethod.POST)
	public ModelAndView editSave(@ModelAttribute("user") User user, @PathVariable("uname") String uname) {
		userdao.update(user);
		return new ModelAndView("error");
	}
	@RequestMapping(value="/deleteuser/${uname}")
	public ModelAndView deleteUser(@ModelAttribute("user") User user,@PathVariable("uname") String uname) {
		userdao.delete(uname);
		return new ModelAndView("dashboard/delete");
		
	}
	
	@RequestMapping("/dashboardcontact")
	public ModelAndView loadAboutFromDash() {
		ModelAndView mav = new ModelAndView("dashboard/contact2");
		return mav;
	}
	@RequestMapping("/clientreg")
	public ModelAndView loadClientReg() {
		ModelAndView mav=new ModelAndView("dashboard/clientreg");
		return mav;
	}
	@RequestMapping("/partnerreg")
	public ModelAndView loadPartnerReg() {
		ModelAndView mav=new ModelAndView("dashboard/partnerreg");
		return mav;
	}
	@RequestMapping("/logout")
	public ModelAndView logOut() {
		ModelAndView mav=new ModelAndView("dashboard/logout");
		return mav;
	}

	

}
